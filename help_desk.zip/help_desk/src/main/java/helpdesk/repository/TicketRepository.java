package helpdesk.repository;

import helpdesk.model.Ticket;
import helpdesk.model.TicketStatus;

import java.util.Optional;
import java.util.ArrayList;
import java.util.List;

public class TicketRepository {

    private final List<Ticket> tickets = new ArrayList<>();

    public void add(Ticket ticket) {
        tickets.add(ticket);
    }

    public List<Ticket> findAll() {
        return new ArrayList<>(tickets);
    }

public List<Ticket> findByStatus(TicketStatus status) {

    List<Ticket> result = new ArrayList<>();

    for (Ticket ticket : tickets) {

        if (ticket.getStatus() == status) {
            result.add(ticket);
        }

    }

    return result;
}

public void getStatistics() {

    int newCount = 0;
    int inProgress = 0;
    int resolved = 0;
    int closed = 0;
    int cancelled = 0;

    for (Ticket ticket : tickets) {

        switch (ticket.getStatus()) {

            case NEW:
                newCount++;
                break;

            case IN_PROGRESS:
                inProgress++;
                break;

            case RESOLVED:
                resolved++;
                break;

            case CLOSED:
                closed++;
                break;

            case CANCELLED:
                cancelled++;
                break;

        }

    }

    System.out.println("\n=== Статистика ===");
    System.out.println("NEW: " + newCount);
    System.out.println("IN_PROGRESS: " + inProgress);
    System.out.println("RESOLVED: " + resolved);
    System.out.println("CLOSED: " + closed);
    System.out.println("CANCELLED: " + cancelled);

}

public Optional<Ticket> findById(long id) {

    for (Ticket ticket : tickets) {
        if (ticket.getId() == id) {
            return Optional.of(ticket);
        }
    }

    return Optional.empty();
}

}