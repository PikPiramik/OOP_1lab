package helpdesk;

import helpdesk.model.*;
import helpdesk.repository.TicketRepository;
import helpdesk.service.EmailNotificationService;
import helpdesk.service.NotificationService;
import helpdesk.service.TicketService;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class Main {

    public static void main(String[] args) {

        System.out.println("=== HELP DESK ===");

        Customer customer = new Customer(
                1,
                "Анна Петрова",
                "anna@mail.ru"
        );

        SupportAgent agent = new SupportAgent(
                2,
                "Сергей Иванов",
                "sergey@helpdesk.ru"
        );

        Administrator admin = new Administrator(
                3,
                "Олег Смирнов",
                "admin@helpdesk.ru"
        );

        List<User> users = new ArrayList<>();
        users.add(customer);
        users.add(agent);
        users.add(admin);

        System.out.println("\n=== Пользователи ===");

        for (User user : users) {
            user.performAction();
        }

        Ticket ticket = new Ticket(
                1,
                "Не работает Wi-Fi",
                "После включения компьютера отсутствует интернет.",
                TicketPriority.HIGH
        );

        Ticket ticket2 = new Ticket(
                2,
                "Ошибка приложения",
                "Приложение закрывается при запуске.",
                TicketPriority.MEDIUM
        );

        Ticket ticket3 = new Ticket(
                3,
                "Не печатает принтер",
                "Документы не отправляются на печать.",
                TicketPriority.LOW
        );

        System.out.println("\nСоздана заявка:");
        System.out.println(ticket);

        NotificationService notificationService =
                new EmailNotificationService();

        TicketService ticketService =
                new TicketService(notificationService);

        ticketService.startTicket(ticket);
        System.out.println("Статус: " + ticket.getStatus());

        ticketService.resolveTicket(ticket);
        System.out.println("Статус: " + ticket.getStatus());

        ticketService.closeTicket(ticket);
        System.out.println("Статус: " + ticket.getStatus());

        TicketRepository repository = new TicketRepository();

        repository.add(ticket);
        repository.add(ticket2);
        repository.add(ticket3);

        System.out.println("\n=== Все заявки ===");

        for (Ticket t : repository.findAll()) {
            System.out.println(t);
        }

        System.out.println("\n=== Поиск по ID ===");

        Optional<Ticket> result = repository.findById(1);

        if (result.isPresent()) {
            System.out.println(result.get());
        } else {
            System.out.println("Заявка не найдена.");
        }

        System.out.println("\n=== Заявки со статусом NEW ===");

        for (Ticket t : repository.findByStatus(TicketStatus.NEW)) {
            System.out.println(t);
        }

        repository.getStatistics();

    }
}