package helpdesk.model;

import java.time.LocalDateTime;

public class Ticket {

    private long id;
    private String title;
    private String description;
    private TicketStatus status;
    private TicketPriority priority;
    private LocalDateTime createdAt;

    public Ticket(long id,
                  String title,
                  String description,
                  TicketPriority priority) {

        this.id = id;
        this.title = title;
        this.description = description;
        this.priority = priority;
        this.createdAt = LocalDateTime.now();
        this.status = TicketStatus.NEW;
    }

    public long getId() {
        return id;
    }

    public TicketPriority getPriority() {
        return priority;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public String getTitle() {
        return title;
    }

    public String getDescription() {
        return description;
    }

    public TicketStatus getStatus() {
        return status;
    }

    public void startProcessing() {
        if (status != TicketStatus.NEW) {
            System.out.println("В работу можно взять только новую заявку.");
            return;
        }
        status = TicketStatus.IN_PROGRESS;
    }

    public void resolve() {
        if (status != TicketStatus.IN_PROGRESS) {
            System.out.println("Решить можно только заявку в работе.");
            return;
        }
        status = TicketStatus.RESOLVED;
    }

    public void close() {
        if (status != TicketStatus.RESOLVED) {
            System.out.println("Закрыть можно только решенную заявку.");
            return;
        }
        status = TicketStatus.CLOSED;
    }

    public void cancel() {
        if (status == TicketStatus.CLOSED) {
            System.out.println("Закрытую заявку отменить нельзя.");
            return;
        }

        status = TicketStatus.CANCELLED;
    }

    @Override
    public String toString() {
        return "Ticket #" + id +
                " | " + title +
                " | " + status +
                " | Priority: " + priority +
                " | Created: " + createdAt;
    }
}